<?php

				$formvalue = $_POST['input_value'];

				require_once("pdf/tcpdf/tcpdf.php");
				$obj_pdf = new TCPDF('p',PDF_UNIT,PDF_PAGE_FORMAT,true,'UTF-8',false);
				$obj_pdf->setCreator(PDF_CREATOR);
				$obj_pdf->SetTitle("Data");
				$obj_pdf->SetHeaderData('','',PDF_HEADER_TITLE,PDF_HEADER_STRING);
				$obj_pdf->SetHeaderFont(array(PDF_FONT_NAME_MAIN,'',PDF_FONT_SIZE_MAIN));
				$obj_pdf->SetFooterFont(array(PDF_FONT_NAME_DATA,'',PDF_FONT_SIZE_DATA));
				$obj_pdf->SetDefaultMonospacedFont('helvetica');
				$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
				$obj_pdf->SetMargins(PDF_MARGIN_LEFT,'5',PDF_MARGIN_RIGHT);
				$obj_pdf->SetPrintHeader(false);
				$obj_pdf->SetPrintFooter(false);
				$obj_pdf->SetAutoPageBreak(TRUE,10);
				$obj_pdf->SetFont('helvetica','',12);
				$obj_pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
				$obj_pdf->AddPage();
				

				//download start more than 75k
				$count = -1;
		   		while($count != 0)
		   		{
		   			$ids = $connection->get('followers/ids',array('count'=>5000,
		   				'screen_name'=>$formvalue,'cursor'=>$count));
            
		            if(isset($ids->errors))
		            {
		            	//fclose($fp);
		               	break;
		            }
		            
		            $count = $ids->next_cursor_str;
           			$ids_arrays = array_chunk($ids->ids, 100);

           			foreach($ids_arrays as $implode) 
           			{
                		$results = $connection->get('users/lookup', array('user_id' => implode(',', $implode)));
                		
               		 	foreach ($results as $profile)
               		  	{
               		  		$c=date('d/m/Y H:i:s',strtotime($profile->created_at));
               		  		$html2 = 
							'<div style="background-color:gray;height:auto;width:auto">
					     		<br/> 
								
								Name : '.$profile->name.' <br/>
								Screen Name :'.$profile->screen_name.' <br/>
								 Created at : '.$c.' 
							</div>
							<br/>';
							$obj_pdf->writeHTMLCell(0,0,'','',$html2,0,1,0,true,'',true);
               			}
               			
            		}  
            	//	ob_end_clean();
					$obj_pdf->Output("Followers_PDF.pdf","D"); 
		   		}

?>