
<html>
<body>
	<form method="POST" action="downloadcompleate.php">
		<input type="text" name="input_value">
		<input type="submit" name="submit">
	</form>
	
</body>
</html>
