<html>
<head></head>
<body>
<?php
if(isset($_REQUEST['btnSave']))
{
	$email = $_REQUEST['email'] ;
	$message = $_REQUEST['message'] ;
	require("PHPMailer_5.2.0/class.PHPMailer.php");
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->Host = "smtp.gmail.com"; 
	$mail->SMTPAuth = true;   
	$mail->Port=465;
	$mail->SMTPSecure = "ssl";
	$mail->Username = "kaklotarkapil75@gmail.com";  // SMTP username
	$mail->Password = "sejal143"; // SMTP password

// $email = $_REQUEST['email'] ;
	$mail->From = "npsystem800@gmail.com" ;	
	$mail->FromName = "kapil" ;
	$mail->AddAddress($email);
	$mail->IsHTML(true);
	$mail->Subject = "You have received Followers CSV File!";
	$mail->Body    = $message;
	$mail->AltBody = $message;

if(!$mail->Send())
{
   echo "Message could not be sent. <p>";
   echo "Mailer Error: " . $mail->ErrorInfo;
   exit;
}

echo "Message has been sent";
}
?>
 
<form method="post">
  Email: <input name="email" id="email" type="text" /><br />

  Message:<br />
  <textarea name="message" id="message" rows="15" cols="40"></textarea><br />

  <input type="submit" value="Submit" name="btnSave" />
</form>

</body>
</html>