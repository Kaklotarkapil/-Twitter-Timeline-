<?php
session_start();
include_once("config.php");
include_once("inc/twitteroauth.php");

if(isset($_SESSION['status']) && $_SESSION['status'] == 'verified') 
{
    //Retrive variables
		$screen_name 		= $_SESSION['request_vars']['screen_name'];
		$twitter_id			= $_SESSION['request_vars']['user_id'];
		$oauth_token 		= $_SESSION['request_vars']['oauth_token'];
		$oauth_token_secret = $_SESSION['request_vars']['oauth_token_secret'];
		
		function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) 
		{
			$connection1 = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);
				return $connection1;
		}
			$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);
		$user_info = $connection->get('account/verify_credentials'); 
		
			$connection1 = getConnectionWithAccessToken(CONSUMER_KEY, CONSUMER_SECRET, $oauth_token, $oauth_token_secret);
			$sc_name=$user_info->screen_name;
		$result = $connection1->get('followers/list', array('count' => 200, 'screen_name' => $screen_name));
			$newFollowers = array();
				
	   if(isset($_POST['create_pdf']))
		{
		 
			
			require_once("pdf/tcpdf/tcpdf.php");
				//ob_start();
			$obj_pdf = new TCPDF('p',PDF_UNIT,PDF_PAGE_FORMAT,true,'UTF-8',false);
			   
			$obj_pdf->setCreator(PDF_CREATOR);
			$obj_pdf->SetTitle("Data");
			$obj_pdf->SetHeaderData('','',PDF_HEADER_TITLE,PDF_HEADER_STRING);
			$obj_pdf->SetHeaderFont(array(PDF_FONT_NAME_MAIN,'',PDF_FONT_SIZE_MAIN));
			$obj_pdf->SetFooterFont(array(PDF_FONT_NAME_DATA,'',PDF_FONT_SIZE_DATA));
			$obj_pdf->SetDefaultMonospacedFont('helvetica');
			$obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
			$obj_pdf->SetMargins(PDF_MARGIN_LEFT,'5',PDF_MARGIN_RIGHT);
			$obj_pdf->SetPrintHeader(false);
			$obj_pdf->SetPrintFooter(false);
			$obj_pdf->SetAutoPageBreak(TRUE,10);
			$obj_pdf->SetFont('helvetica','',12);
			$obj_pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
			$obj_pdf->AddPage();
			
			foreach($result->users as $user)
			{
			
				$html2 = 
				'<div style="background-color:gray;height:auto;width:auto">
		     		<img src="'.$user->profile_image_url.'" style="height:32px;width:32px;border:1px solid black"/>
					'.$user->name.' <br/> 
					'.date('d/m/Y H:i:s',strtotime($user->created_at)).' <br/>Followers:
					 '.$user->followers_count.' <br/>following:
					  '.$user->friends_count.' <br/>Tweet:
					  '.$user->statuses_count.' 
				</div>
				<br/>';
				$obj_pdf->writeHTMLCell(0,0,'','',$html2,0,1,0,true,'',true);
						
			}
            
		   // ob_end_clean();
			$obj_pdf->Output("MyFollowers.pdf","I");
	

		}
}

?>