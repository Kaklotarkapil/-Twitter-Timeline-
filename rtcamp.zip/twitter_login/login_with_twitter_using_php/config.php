<?php
define('CONSUMER_KEY', 'bFmzbRaaXTXIkMD5elOciapuQ');
define('CONSUMER_SECRET', 'H1Kzyr0W9dVQ6zY6o5VZGqFbu5AZCR3CkzZiGLVrfnuLfjzbri');
define('OAUTH_CALLBACK', 'https://kapilkaklotar.xyz/twitter_login/login_with_twitter_using_php/process.php');
?>