<?php
session_start();
//$url_array = explode('?', 'http://'.$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI']);
$url = "https://kapilkaklotar.xyz/twitter_login/UploadCSVGoogleDrive/";

require_once 'google-api-php-client/src/Google_Client.php';
require_once 'google-api-php-client/src/contrib/Google_DriveService.php';

$client = new Google_Client();
$client->setClientId('693898778895-apc5tjroaovjtf4rf72u5ns8vntcb14g.apps.googleusercontent.com');
$client->setClientSecret('AzT1N-MXLFhHnyLKSGjbbPzJ');

$client->setRedirectUri($url);
$client->setScopes(array('https://www.googleapis.com/auth/drive'));

if (isset($_GET['code'])) 
{
    $_SESSION['accessToken'] = $client->authenticate($_GET['code']);
    header('location:'.$url);exit;
}
elseif (!isset($_SESSION['accessToken']))
{
    $client->authenticate();
}

$files= array();
$dir = dir('files');
while ($file = $dir->read()) 
{
    if ($file != '.' && $file != '..')
    {
        $files[] = $file;
    }
}
$dir->close();

if (!empty($_POST))
{
    $client->setAccessToken($_SESSION['accessToken']);
    $service = new Google_DriveService($client);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $file = new Google_DriveFile();
    foreach ($files as $file_name)
    {
        $file_path = 'files/'.$file_name;
        $mime_type = finfo_file($finfo, $file_path);
        $file->setTitle($file_name);
        $file->setDescription('This is a '.$mime_type.' document');
        $file->setMimeType($mime_type);
        $service->files->insert(
            $file,
            array(
                'data' => file_get_contents($file_path),
                'mimeType' => $mime_type
            )
        );
    }
    finfo_close($finfo);
    
    //$path1="../UploadCSVGoogleDrive/files/Followes_CSV.csv";

    //if(unlink($path1))
//    {

    $path="../login_with_twitter_using_php/Home.php";
    header("location:".$path);
//    }
    //header('location:'.$url);exit;
}
?>
<html>
<body>
<ul>
        <?php foreach ($files as $file) { ?>
            <li><?php echo $file; ?></li>
        <?php } ?>
        </ul>
        <form method="post" action="<?php echo $url; ?>">
            <input type="submit" value="Upload" name="submit">
            <a href="../login_with_twitter_using_php/Home.php">back to Home Page</a>
        </form>
</body>
</html>